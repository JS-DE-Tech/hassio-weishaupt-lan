Weishaupt targeted correlation scan
====================================

Purpose
-------
This package performs a targeted, strictly read-only CanApiJson scan for the
real dynamic module areas inferred from systable.csv:

  09/00 -> Systemgeraet or HK1-near values
  09/01 -> WTC boiler reference values
  09/02 -> HK2-near values
  09/03 -> HK3-near values

The script never sends write commands. It uses only numeric GET frames with
CMD 0x01 and limits every batch to six frames.

Files
-----
START-targeted-correlation.cmd
  Double-click launcher. It starts PowerShell with a process-local execution
  policy bypass.

weishaupt-targeted-correlation.ps1
  Main read-only scan script.

Recommended first run
---------------------
1. Double-click START-targeted-correlation.cmd
2. Choose:
     2 = Focused
3. Enter a snapshot label, for example:
     baseline_brenner_aus
4. The script uses the default password `Admin123` automatically.
5. Wait until Explorer opens the result folder.
6. ZIP the complete result folder and upload it for analysis.

Recommended correlation runs
----------------------------
Run additional snapshots after changing the operating state at the heating
system. Use descriptive labels:

  brenner_aus
  heizbetrieb_aktiv
  warmwasserladung_aktiv
  pumpennachlauf
  hk2_pumpe_ein
  hk2_pumpe_aus
  hk3_pumpe_ein
  hk3_pumpe_aus

The script creates changed-values-vs-previous-run.csv when a previous completed
scan exists.

Profiles
--------
Quick
  Reads the existing curated addresses across 09/00..09/03.

Focused
  Reads the curated addresses plus selected adjacent object blocks:
    2610-261F
    2630-263F
    2670-267F
    2680-268F
    2900-290F
    2920-292F
  with subindices 00, 01, 02 and VS 1, 2, 4.

Resume after interruption
-------------------------
Progress is saved after every batch. If PowerShell is closed accidentally, run
START-targeted-correlation.cmd again. The script offers to resume the incomplete
run.

Output
------
The visible output folder is created on the Desktop:

  Desktop\Weishaupt_Targeted_Correlation

Each completed scan contains:
  results.csv
  results.jsonl
  supported-values.csv
  unsupported-or-errors.csv
  state-like-raw-0-or-1.csv
  changed-values-vs-previous-run.csv   (when a prior scan exists)
  summary.json
  run-metadata.json
  probe-plan.json

Security
--------
- Read-only GET requests only
- No SET or SETS commands
- Password is requested interactively
- Password is not written to output files
- No credentials are printed


Version 2 corrections
---------------------
- Uses the confirmed CanApiJson request source identifier:
    SRC = DDC
- Adds a read-only protocol preflight before discovery starts.
- Stops immediately when the confirmed HK1 test register does not return a
  normal CMD_RESPONSE.
- Adds a conservative default delay of 300 ms between batches.
- Keeps the maximum batch size at six frames.

Why this was changed
--------------------
The first targeted run completed 3,456 frames in approximately 88 seconds with
no inter-batch delay. All frames returned CMD_ERROR, including already known
working WTC candidates. The main cause was the incorrect SRC value SYS. The
additional delay is a conservative safeguard for the embedded controller.


Version 3 convenience change
----------------------------
- Uses the documented Weishaupt default password automatically:
    Admin123
- No password prompt appears during a normal double-click start.
- A different password can still be supplied explicitly:
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\weishaupt-targeted-correlation.ps1" -Password "YourPassword"
- The password is not written to result files.
